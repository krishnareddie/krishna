//
//  ArtistDetails.h
//  MoviesApplication
//
//  Created by Student on 01/04/16.
//  Copyright © 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ArtistDetails : UIViewController
@property NSString * artistName;
@property UIImage * artistIMage;
@property NSString * artistDescription;

@property (weak, nonatomic) IBOutlet UILabel *artistNameLabel;

@property (weak, nonatomic) IBOutlet UIImageView *artistImageView;
@property (weak, nonatomic) IBOutlet UITextView *artistTextDiscription;


@end
