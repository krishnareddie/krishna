//
//  ArtistDetails.m
//  MoviesApplication
//
//  Created by Student on 01/04/16.
//  Copyright © 2016 Student. All rights reserved.
//

#import "ArtistDetails.h"
#import "ArtistWikipedia.h"
@interface ArtistDetails ()

@end

@implementation ArtistDetails

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.artistNameLabel.text=self.artistName;
    self.artistImageView.image=self.artistIMage;
    self.artistTextDiscription.text=self.artistDescription;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"suriyaDetails.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Suriya";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"samanthaDetails.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Samantha_Ruth_Prabhu";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"nithyaD.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Nithya_Menen";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"girishD.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Girish_Karnad";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"sD.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Saranya_Ponvannan";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"nD.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Nivin_Pauly";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"Sai-Pallavi-D.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Sai_Pallavi";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"Anupama-ParameswaranD.png"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"http://www.cochintalkies.com/celebrity/anupama-parameswaran.html";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"madonnaD.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Madonna_Sebastian";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"vd.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Vinay_Forrt";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"ajithD.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Ajith_Kumar";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"trishaD.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Trisha_(actress)";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"anushka.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Anushka_Shetty";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"Parvathy-Nair.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Parvathy_Nair";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"arunvjd.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Arun_Vijay";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"suriyaDetails.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Suriya";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"suriyaDetails.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Suriya";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"suriyaDetails.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Suriya";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"suriyaDetails.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Suriya";
        
        
    }
    if ([segue.identifier isEqualToString:@"wikipediaPage"]&&[self.artistImageView.image isEqual:[UIImage imageNamed:@"suriyaDetails.jpg"]]){
        
        ArtistWikipedia * artistWikipedia=[segue destinationViewController];
        artistWikipedia.urlStrig=@"https://en.wikipedia.org/wiki/Suriya";
        
        
    }

    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
