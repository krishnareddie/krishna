//
//  ActorsWikipedia.h
//  MoviesApplication
//
//  Created by Student on 01/04/16.
//  Copyright © 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ArtistWikipedia : UIViewController

@property (weak, nonatomic) IBOutlet UIWebView *artistsWikipedia;

@property NSURL *urlName;
@property NSURLRequest *urlRequest;
@property NSString * urlStrig;
@end
