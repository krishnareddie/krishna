//
//  Artists.h
//  MoviesApplication
//
//  Created by Student on 01/04/16.
//  Copyright © 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Artists : UIViewController


@property (weak, nonatomic) IBOutlet UIImageView *artist1;
@property (weak, nonatomic) IBOutlet UIImageView *artist2;
@property (weak, nonatomic) IBOutlet UIImageView *artist3;
@property (weak, nonatomic) IBOutlet UIImageView *artist4;
@property (weak, nonatomic) IBOutlet UIImageView *artist5;

@property UIImage * artist1Image,*artist2Image,*artist3Image,*artist4Image,*artist5Image;


@end
