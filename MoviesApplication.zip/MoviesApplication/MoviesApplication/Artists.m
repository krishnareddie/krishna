//
//  Artists.m
//  MoviesApplication
//
//  Created by Student on 01/04/16.
//  Copyright © 2016 Student. All rights reserved.
//

#import "Artists.h"
#import "ArtistDetails.h"
@interface Artists ()

@end

@implementation Artists

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.artist1 setImage:self.artist1Image];
    [self.artist2 setImage:self.artist2Image];

    [self.artist3 setImage:self.artist3Image];

    [self.artist4 setImage:self.artist4Image];

    [self.artist5 setImage:self.artist5Image];

    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{

//    if ([segue.identifier isEqualToString:@"ADToActors"]&& ()) {
//        
//        
//        
//    }
//    if ([segue.identifier isEqualToString:@"ADToActors"]) {
//        
//        Artists * artistsData=[segue  destinationViewController];
//        
//        artistsData.artist1Image= [UIImage imageNamed:@"nithya.jpg"];
//        artistsData.artist2Image=[UIImage imageNamed:@"Samantha.jpg"];
//        artistsData.artist3Image=[UIImage imageNamed:@"Suriya.jpg"];
//        artistsData.artist4Image=[UIImage imageNamed:@"Girish Karnad.jpg"];
//        artistsData.artist5Image=[UIImage imageNamed:@"Saranya.jpg"];
//        
//    }else if ([segue.identifier isEqualToString:@"premamMovieArtists"]){
//        
//        Artists * artistsData=[segue  destinationViewController];
//        
//        artistsData.artist1Image= [UIImage imageNamed:@"anupama-parameswaran-.jpg"];
//        artistsData.artist2Image=[UIImage imageNamed:@"sai-pallavi.jpg"];
//        artistsData.artist3Image=[UIImage imageNamed:@"nivin.jpg"];
//        artistsData.artist4Image=[UIImage imageNamed:@"Madonna-Sebastian.jpg"];
//        artistsData.artist5Image=[UIImage imageNamed:@"-vinay-forrt-is-.jpg"];
//        
//    }else if ([segue.identifier isEqualToString:@"yennaiArindhalArtists"]){
//        
//        Artists * artistsData=[segue  destinationViewController];
//        
//        artistsData.artist1Image= [UIImage imageNamed:@"Anushka-Shetty.JPG"];
//        artistsData.artist2Image=[UIImage imageNamed:@"Trisha Krishnan .png"];
//        artistsData.artist3Image=[UIImage imageNamed:@"Ajith .jpg"];
//        artistsData.artist4Image=[UIImage imageNamed:@"parvathy-nairD.jpg"];
//        artistsData.artist5Image=[UIImage imageNamed:@"arunvj.jpg"];
//        
//    }

    
    
    
    
    if ([segue.identifier isEqualToString:@"artist3Details"]&&self.artist3.image && [self.artist3Image isEqual:[UIImage imageNamed:@"Suriya.jpg"]]) {
        
        ArtistDetails * artistDetails=[segue destinationViewController];
        artistDetails.artistIMage=[UIImage imageNamed:@"suriyaDetails.jpg"];
        artistDetails.artistName=@"SURIYA";
        artistDetails.artistDescription=@"Saravanan Sivakumar, better known by his stage name Suriya, is an Indian film actor, producer and television presenter, who is currently working in the Tamil film industry. WikipediaBorn: July 23, 1975 (age 40), Chennai Height:1.67 m Spouse: Jyothika (m. 2006)";
        
    }
    else if ([segue.identifier isEqualToString:@"artist1Details"]&&self.artist2.image && [self.artist2Image isEqual:[UIImage imageNamed:@"Samantha.jpg"]]) {
        
        ArtistDetails * artistDetails=[segue destinationViewController];
        artistDetails.artistIMage=[UIImage imageNamed:@"samanthaDetails.jpg"];
        artistDetails.artistName=@"Samantha Ruth Prabhu";
        artistDetails.artistDescription=@"Samantha Ruth Prabhu is an Indian actress and model. One of the most popular and highest-paid South Indian actresses, she has established a career in the Telugu and Tamil film industries, and is a recipient of three Filmfare Awards. WikipediaBorn: April 28, 1987 (age 28), ChennaiHeight: 1.68 mUpcoming movies: Theri, Brahmotsavam, Janatha GaragSiblings: Jonathan Prabhu, David Prabhu";
        
    }
    else if ([segue.identifier isEqualToString:@"artist2Details"]&&self.artist1.image && [self.artist1Image isEqual:[UIImage imageNamed:@"nithya.jpg"]]) {
        
        ArtistDetails * artistDetails=[segue destinationViewController];
        artistDetails.artistIMage=[UIImage imageNamed:@"nithyaD.jpg"];
        artistDetails.artistName=@"Nithya Menen";
        artistDetails.artistDescription=@"Nithya Menen is an Indian film actress and playback singer. She has acted in Telugu, Tamil, Malayalam and Kannada language films, as well as an English film. WikipediaBorn: April 8, 1988 (age 27), BengaluruHeight: 1.6 mUpcoming movies: Janatha Garage, Mudinja Ivana PudiNominations: Vijay Award for Best Actress, more";
        
    }
   else if ([segue.identifier isEqualToString:@"artist4Details"]&&self.artist4.image && [self.artist4Image isEqual:[UIImage imageNamed:@"Girish Karnad.jpg"]]) {
        
        ArtistDetails * artistDetails=[segue destinationViewController];
        artistDetails.artistIMage=[UIImage imageNamed:@"girishD.jpg"];
        artistDetails.artistName=@"Girish Karnad";
        artistDetails.artistDescription=@"Girish Raghunath Karnad is an Indian actor, film director, writer and playwright who predominantly works in South Indian cinema. WikipediaBorn: May 19, 1938 (age 77), MatheranSpouse: Saraswathy GanapathyMovies: Manthan, Ek Tha Tiger, Swami, Ananda Bhairavi, morePlays: The Dreams of Tipu Sultan, Taledanda, The Fire and the RainChildren: Shalmali Radha Karnad, Raghu Amay Karnad";
        
    }
  else if ([segue.identifier isEqualToString:@"artist5Details"]&&self.artist5.image && [self.artist5Image isEqual:[UIImage imageNamed:@"Saranya.jpg"]]) {
        
        ArtistDetails * artistDetails=[segue destinationViewController];
        artistDetails.artistIMage=[UIImage imageNamed:@"sD.jpg"];
        artistDetails.artistName=@"Saranya Ponvannan";
        artistDetails.artistDescription=@"Saranya Ponvannan is an Indian film actress who has predominantly appeared in Tamil language films. Saranya made her debut in a lead role in Mani Ratnam's Nayagan and went on to play lead roles in a few films during the late 1980s. WikipediaBorn: April 26, 1970 (age 45), AlappuzhaSpouse: Ponvannan (m. 1995)Parents: A. B. RajAwards: National Film Award for Best Actress, more";
        
    }
    
  else  if ([segue.identifier isEqualToString:@"artist3Details"]&&self.artist3.image && [self.artist3Image isEqual:[UIImage imageNamed:@"nivin.jpg"]]) {
      
      ArtistDetails * artistDetails=[segue destinationViewController];
      artistDetails.artistIMage=[UIImage imageNamed:@"nD.jpg"];
      artistDetails.artistName=@"nivin";
      artistDetails.artistDescription=@"Nivin Pauly is an Indian film actor and producer best known for his work in Malayalam cinema. Nivin made his acting debut with Malarvaadi Arts Club which was directed by Vineeth Sreenivasan and produced by Dileep. WikipediaBorn: October 11, 1984 (age 31), AluvaSpouse: Rinna Joy (m. 2010)Parents: Pauly BonaventureChildren: Daveed Pauly";
      
  }

  else if ([segue.identifier isEqualToString:@"artist1Details"]&&self.artist2.image && [self.artist2Image isEqual:[UIImage imageNamed:@"sai-pallavi.jpg"]]) {
      
      ArtistDetails * artistDetails=[segue destinationViewController];
      artistDetails.artistIMage=[UIImage imageNamed:@"Sai-Pallavi-D.jpg"];
      artistDetails.artistName=@"Sai Pallavi";
      artistDetails.artistDescription=@"Sai Pallavi is an Indian film actress best known for her role as Malar in the 2015 Malayalam blockbuster Premam, which was her debut film. In 2016, she is to star in Kali opposite Dulquer Salmaan. Wikipedia Born: May 9, 1992 (age 23), Kotagiri Education: Tbilisi State Medical University Siblings: Puja Kannan Movies: Premam, Kali Awards: Asianet Film Award for Honour Special Jury Parents: Radha Kannan, Senthamara Kannan";
      
  }
  else if ([segue.identifier isEqualToString:@"artist2Details"]&&self.artist1.image && [self.artist1Image isEqual:[UIImage imageNamed:@"anupama-parameswaran-.jpg"]]) {
      
      ArtistDetails * artistDetails=[segue destinationViewController];
      artistDetails.artistIMage=[UIImage imageNamed:@"Anupama-ParameswaranD.png"];
      artistDetails.artistName=@"Anupama Parameshwaran";
      artistDetails.artistDescription=@"Born: February 18, 1996 (age 20) Upcoming movies: Yevado Okadu, Premam Siblings: Akshay Parameshwaran Parents: Parameshwaran, Sunitha Parameshwaran";
      
  }
  else if ([segue.identifier isEqualToString:@"artist4Details"]&&self.artist4.image && [self.artist4Image isEqual:[UIImage imageNamed:@"Madonna-Sebastian.jpg"]]) {
      
      ArtistDetails * artistDetails=[segue destinationViewController];
      artistDetails.artistIMage=[UIImage imageNamed:@"madonnaD.jpg"];
      artistDetails.artistName=@"Madonna Sebastian";
      artistDetails.artistDescription=@"Madonna Sebastian is an Indian film actress and singer. She made her debut in the 2015 Malayalam film, Premam. Wikipedia Born: Kolenchery Height: 1.68 m Alma mater: Christ University Siblings: Michelle Sebastian Upcoming movies: King Liar, Premam";
      
  }
  else if ([segue.identifier isEqualToString:@"artist5Details"]&&self.artist5.image && [self.artist5Image isEqual:[UIImage imageNamed:@"-vinay-forrt-is-.jpg"]]) {
      
      ArtistDetails * artistDetails=[segue destinationViewController];
      artistDetails.artistIMage=[UIImage imageNamed:@"vd.jpg"];
      artistDetails.artistName=@"Vinay Forrt";
      artistDetails.artistDescription=@"Vinay Forrt is an Indian film and theater actor. He hails from Fort Kochi in Kerala and is a theatre activist with more than a decade's worth of experience in the theatrical field as well as a postgraduate ... Wikipedia Born: January 13, 1983 (age 33), Fort Kochi, Ernakulam district Siblings: Suma, Syam Parents: M.V.Mani, Sujatha Upcoming movie: The Blueberry Hunt";
      
  }


  else  if ([segue.identifier isEqualToString:@"artist3Details"]&&self.artist3.image && [self.artist3Image isEqual:[UIImage imageNamed:@"Ajith .jpg"]]) {
      
      ArtistDetails * artistDetails=[segue destinationViewController];
      artistDetails.artistIMage=[UIImage imageNamed:@"ajithD.jpg"];
      artistDetails.artistName=@"Ajith Kumar";
      artistDetails.artistDescription=@"Ajith Kumar is an Indian film actor working predominantly in Tamil cinema. He has won four Filmfare Best Actor Awards, all for films which showcased him in multiple roles. Wikipedi Born: May 1, 1971 (age 44), Secunderabad Height: 1.8 m Spouse: Shalini Kumar (m. 2000) Siblings: Anoop Kumar, Anil Kumar";
      
  }
    
  else if ([segue.identifier isEqualToString:@"artist1Details"]&&self.artist2.image && [self.artist2Image isEqual:[UIImage imageNamed:@"Trisha Krishnan .png"]]) {
      
      ArtistDetails * artistDetails=[segue destinationViewController];
      artistDetails.artistIMage=[UIImage imageNamed:@"trishaD.jpg"];
      artistDetails.artistName=@"Trisha Krishnan";
      artistDetails.artistDescription=@"Trisha Krishnan, known mononymously as Trisha, is an Indian film actress and model, who primarily works in the South Indian film industries, where she has established herself as a leading actress. Wikipedia Born: May 4, 1983 (age 32), Chennai Height: 1.73 m Parents: Uma Krishnan, Krishnan";
      
  }
  else if ([segue.identifier isEqualToString:@"artist2Details"]&&self.artist1.image && [self.artist1Image isEqual:[UIImage imageNamed:@"Anushka-Shetty.JPG"]]) {
      
      ArtistDetails * artistDetails=[segue destinationViewController];
      artistDetails.artistIMage=[UIImage imageNamed:@"anushka.jpg"];
      artistDetails.artistName=@"Anushka Shetty";
      artistDetails.artistDescription=@"Anushka Shetty is an Indian film actress, who works mainly in the Telugu and Tamil film industries. Born in Mangalore, Anushka started her career as a yoga instructor. It was while teaching yoga, she got an offer to act in films.Born: November 7, 1981 (age 34), Mangalore Height: 1.78 m Upcoming movie: Baba Sathya Sai Siblings: Gunaranjan Shetty, Sai Ramesh Shetty";
      
  }
  else if ([segue.identifier isEqualToString:@"artist4Details"]&&self.artist4.image && [self.artist4Image isEqual:[UIImage imageNamed:@"parvathy-nairD.jpg"]]) {
      
      ArtistDetails * artistDetails=[segue destinationViewController];
      artistDetails.artistIMage=[UIImage imageNamed:@"Parvathy-Nair.jpg"];
      artistDetails.artistName=@"Parvathy Nair";
      artistDetails.artistDescription=@"Parvathy Nair is an Indian model and actress, who works in the South Indian film industry. Born into a Malayali family in Abu Dhabi, she trained as a software professional and also pursued a career in modelling before becoming an actress. ";
      
  }
  else if ([segue.identifier isEqualToString:@"artist5Details"]&&self.artist5.image && [self.artist5Image isEqual:[UIImage imageNamed:@"arunvj.jpg"]]) {
      
      ArtistDetails * artistDetails=[segue destinationViewController];
      artistDetails.artistIMage=[UIImage imageNamed:@"arunvjd.jpg"];
      artistDetails.artistName=@"Arun Vijay";
      artistDetails.artistDescription=@"Arun Vijay is an Indian actor, playback singer & stunt coordinator. He is the only son of veteran film actor Vijayakumar and has been active in the Tamil film industry since 1995";
      
  }
    

    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
