//
//  ViewController.m
//  MoviesApplication
//
//  Created by Student on 01/04/16.
//  Copyright © 2016 Student. All rights reserved.
//

#import "ViewController.h"
#import "Artists.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"24MovieArtists"]) {
    
        Artists * artistsData=[segue  destinationViewController];
        
        artistsData.artist1Image= [UIImage imageNamed:@"nithya.jpg"];
        artistsData.artist2Image=[UIImage imageNamed:@"Samantha.jpg"];
        artistsData.artist3Image=[UIImage imageNamed:@"Suriya.jpg"];
        artistsData.artist4Image=[UIImage imageNamed:@"Girish Karnad.jpg"];
        artistsData.artist5Image=[UIImage imageNamed:@"Saranya.jpg"];
        
    }else if ([segue.identifier isEqualToString:@"premamMovieArtists"]){
        
        Artists * artistsData=[segue  destinationViewController];
        
        artistsData.artist1Image= [UIImage imageNamed:@"anupama-parameswaran-.jpg"];
        artistsData.artist2Image=[UIImage imageNamed:@"sai-pallavi.jpg"];
        artistsData.artist3Image=[UIImage imageNamed:@"nivin.jpg"];
        artistsData.artist4Image=[UIImage imageNamed:@"Madonna-Sebastian.jpg"];
        artistsData.artist5Image=[UIImage imageNamed:@"-vinay-forrt-is-.jpg"];

    }else if ([segue.identifier isEqualToString:@"yennaiArindhalArtists"]){
        
        Artists * artistsData=[segue  destinationViewController];
        
        artistsData.artist1Image= [UIImage imageNamed:@"Anushka-Shetty.JPG"];
        artistsData.artist2Image=[UIImage imageNamed:@"Trisha Krishnan .png"];
        artistsData.artist3Image=[UIImage imageNamed:@"Ajith .jpg"];
        artistsData.artist4Image=[UIImage imageNamed:@"parvathy-nairD.jpg"];
        artistsData.artist5Image=[UIImage imageNamed:@"arunvj.jpg"];
        
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
